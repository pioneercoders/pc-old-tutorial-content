 var app=angular.module('userModule',[]);
  app.controller('userCtrl',function($scope)
 { 
 });
 